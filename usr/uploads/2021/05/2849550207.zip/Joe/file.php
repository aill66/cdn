<?php

/**
 * 归档
 * 
 * @package custom 
 * 
 **/

?>

<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <?php $this->need('public/include.php'); ?>
    <!-- 归档页面需要用到的CSS及JS -->
    <link rel="stylesheet" href="<?php $this->options->themeUrl('assets/css/joe.file.min.css'); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs@1.23.0/themes/prism-tomorrow.min.css">
    <script src="https://cdn.jsdelivr.net/npm/clipboard@2.0.6/dist/clipboard.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/typecho-joe-next@6.2.4/plugin/prism/prism.min.js"></script>
    <script src="<?php $this->options->themeUrl('assets/js/joe.post_page.min.js'); ?>"></script>
</head>

<body>
    <div id="Joe">
        <?php $this->need('public/header.php'); ?>
        <div class="joe_container">
            <div class="joe_main">
                <div class="joe_detail" data-cid="<?php echo $this->cid ?>">
                    <?php $this->need('public/batten.php'); ?>
                    <?php $this->need('public/article.php'); ?>
                    <div class="joe_file">
                        <?php $this->widget('Widget_Contents_Post_Recent', 'pageSize=10000')->to($archives);
                        $year = 0;
                        $mon = 0;
                        $i = 0;
                        $j = 0;
                        $output = '';
                        while ($archives->next()) :
                            $year_tmp = date('Y', $archives->created);
                            $mon_tmp = date('m', $archives->created);
                            if ($mon != $mon_tmp && $mon > 0) $output .= '</ul></div>';
                            if ($year != $year_tmp && $year > 0) $output .= '</ul></div>';
                            if ($mon != $mon_tmp) {
                                $mon = $mon_tmp;
                                $output .= '<div class="item"><span class="panel">' . $year_tmp . ' 年 ' . $mon . ' 月<svg viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg"><path d="M21.6 772.8c28.8 28.8 74.4 28.8 103.2 0L512 385.6 899.2 772.8c28.8 28.8 74.4 28.8 103.2 0 28.8-28.8 28.8-74.4 0-103.2l-387.2-387.2-77.6-77.6c-14.4-14.4-37.6-14.4-51.2 0l-77.6 77.6-387.2 387.2c-28.8 28.8-28.8 75.2 0 103.2z"></path></svg></span><ul class="panel-body">';
                            }
                            $output .= '<li><a href="' . $archives->permalink . '">' . date('m/d：', $archives->created) . $archives->title . '</a>';
                            $output .= '</li>';
                        endwhile;
                        $output .= '</ul></div>';
                        echo $output;
                        ?>
                    </div>
                    <?php $this->need('public/handle.php'); ?>
                    <?php $this->need('public/copyright.php'); ?>
                </div>
            </div>
            <?php $this->need('public/aside.php'); ?>
        </div>
        <?php $this->need('public/footer.php'); ?>
    </div>
</body>
<script>
    $(document).ready(function() {
        /* 初始化归档下拉 */
        $('.joe_file .panel').first().next().slideToggle(0)
        $('.joe_file .panel').on('click', function() {
            let next = $(this).next()
            next.slideToggle(200)
            $('.joe_file .panel-body').not(next).slideUp()
        })
    })
</script>

</html>